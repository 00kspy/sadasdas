﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Veltrix
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Grid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void Key_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Key_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            KeyTextBox.Text = "";
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {

        }
        

        private void GetKey_Click(object sender, RoutedEventArgs e)
        {
            Process.Start("https://discord.gg/mw9jph4E7J");
        }
    }
}
